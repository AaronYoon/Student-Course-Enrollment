package com.csuf.cpsc41101.assignment3_final;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Activity2 extends AppCompatActivity {

    //private ArrayList<String> arrayList;
    //private ArrayAdapter<String> adapter;
    //private EditText txtInput;

    NewUser db;
    Button add_button, add_class, button;
    EditText firstname, lastname, cwid;

    //ListView userlist;

    //ArrayList<String> listItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        db = new NewUser(this);

        //listItem = new ArrayList<>();
        //add_button = (Button) findViewById(R.id.addstudent);
        firstname = (EditText) findViewById(R.id.firstname);
        lastname = (EditText) findViewById(R.id.lastname);
        cwid = (EditText) findViewById(R.id.CWID);
        //userlist = (ListView) findViewById(R.id.listView);

        /*
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.insertData(firstname.getText().toString(), lastname.getText().toString(), cwid.getText().toString());
                boolean isInserted = db.insertData(firstname.getText().toString(),
                        lastname.getText().toString(),
                        cwid.getText().toString());
                if (isInserted == true)
                    Toast.makeText(Activity2.this, "Data added", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Activity2.this, "Data not added", Toast.LENGTH_LONG).show();
            }
        });

         */

        /*
        add_class.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                list.add(findViewById(R.id.courselist));
                courselist.setAdapter(arrayAdapter);
            }
        });

         */

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menudone, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.item1:
                goMainActivity();
                boolean isInserted = db.insertData(firstname.getText().toString(), lastname.getText().toString(), cwid.getText().toString());
                if (isInserted == true)
                    Toast.makeText(Activity2.this, "Data added", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Activity2.this, "Data not added", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
    public void goMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}




